// $Id: OS_NS_sys_time.cpp 95719 2012-05-01 12:54:01Z johnnyw $

#include "ace/OS_NS_sys_time.h"

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_NS_sys_time.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */


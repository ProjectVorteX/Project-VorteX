// $Id: OS_NS_sys_msg.cpp 92837 2010-12-08 17:31:02Z johnnyw $

#include "ace/OS_NS_sys_msg.h"

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_NS_sys_msg.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */


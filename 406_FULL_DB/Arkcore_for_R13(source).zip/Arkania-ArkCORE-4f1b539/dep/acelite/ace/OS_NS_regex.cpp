// $Id: OS_NS_regex.cpp 91781 2010-09-15 12:49:15Z johnnyw $

#include "ace/OS_NS_regex.h"

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_NS_regex.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */

